package com.example.holamundoprueba;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HolaMundoPruebaApplicationTests {

    @Test
    void contextLoads() {
    }

}
